/*
 * Controlador.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Controlador".
 *
 * Model version              : 1.27
 * Simulink Coder version : 24.2 (R2024b) 21-Jun-2024
 * C++ source code generated on : Mon Mar 16 23:44:20 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef Controlador_h_
#define Controlador_h_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "Controlador_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block states (default storage) for system '<Root>' */
struct DW_Controlador_T {
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S1>/Discrete-Time Integrator' */
};

/* External inputs (root inport signals with default storage) */
struct ExtU_Controlador_T {
  real_T In1;                          /* '<Root>/In1' */
  real_T In2;                          /* '<Root>/In2' */
};

/* External outputs (root outports fed by signals with default storage) */
struct ExtY_Controlador_T {
  real_T Out1;                         /* '<Root>/Out1' */
};

/* Real-time Model Data Structure */
struct tag_RTM_Controlador_T {
  const char_T *errorStatus;
};

/* Class declaration for model Controlador */
class Controlador final
{
  /* public data and function members */
 public:
  /* Copy Constructor */
  Controlador(Controlador const&) = delete;

  /* Assignment Operator */
  Controlador& operator= (Controlador const&) & = delete;

  /* Move Constructor */
  Controlador(Controlador &&) = delete;

  /* Move Assignment Operator */
  Controlador& operator= (Controlador &&) = delete;

  /* Real-Time Model get method */
  RT_MODEL_Controlador_T * getRTM();

  /* Root inports set method */
  void setExternalInputs(const ExtU_Controlador_T *pExtU_Controlador_T)
  {
    Controlador_U = *pExtU_Controlador_T;
  }

  /* Root outports get method */
  const ExtY_Controlador_T &getExternalOutputs() const
  {
    return Controlador_Y;
  }

  /* Initial conditions function */
  void initialize();

  /* model step function */
  void step();

  /* model terminate function */
  static void terminate();

  /* Constructor */
  Controlador();

  /* Destructor */
  ~Controlador();

  /* private data and function members */
 private:
  /* External inputs */
  ExtU_Controlador_T Controlador_U;

  /* External outputs */
  ExtY_Controlador_T Controlador_Y;

  /* Block states */
  DW_Controlador_T Controlador_DW;

  /* Real-Time Model */
  RT_MODEL_Controlador_T Controlador_M;
};

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('Aerogenerador_lab/Controlador PI')    - opens subsystem Aerogenerador_lab/Controlador PI
 * hilite_system('Aerogenerador_lab/Controlador PI/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Aerogenerador_lab'
 * '<S1>'   : 'Aerogenerador_lab/Controlador PI'
 */
#endif                                 /* Controlador_h_ */
