/*
 * Controlador_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Controlador".
 *
 * Model version              : 1.27
 * Simulink Coder version : 24.2 (R2024b) 21-Jun-2024
 * C++ source code generated on : Mon Mar 16 23:44:20 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef Controlador_private_h_
#define Controlador_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "Controlador_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* Controlador_private_h_ */
