#include <stdio.h>
#include <stdlib.h>
#include "Controlador.h"

int main(int argc, char* argv[])
{
    real_T inputIn1 = atof(argv[1]);
    real_T inputIn2 = atof(argv[2]);

    Controlador controller;
    controller.initialize();

    ExtU_Controlador_T inputs;
    inputs.In1 = inputIn1;
    inputs.In2 = inputIn2;
    controller.setExternalInputs(&inputs);

    controller.step();

    const ExtY_Controlador_T& outputs = controller.getExternalOutputs();

    printf("\n--- Entradas del Controlador ---\n");
    printf("Velocidad deseada : %.4f rad/s\n", inputIn1);
    printf("Velocidad actual  : %.4f rad/s\n", inputIn2);
    
    printf("\n--- Salida del Controlador ---\n");
    printf("Accion de pitch   : %.4f grados\n\n", outputs.Out1);

    controller.terminate();

    return 0;
}
