/*
 * Controlador.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Controlador".
 *
 * Model version              : 1.27
 * Simulink Coder version : 24.2 (R2024b) 21-Jun-2024
 * C++ source code generated on : Mon Mar 16 23:44:20 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#include "Controlador.h"
#include "rtwtypes.h"

/* Model step function */
void Controlador::step()
{
  real_T rtb_Accinsinsaturar;
  real_T rtb_Gain1;

  /* Outputs for Atomic SubSystem: '<Root>/Controlador PI' */
  /* Sum: '<S1>/Sum1' incorporates:
   *  Inport: '<Root>/In1'
   *  Inport: '<Root>/In2'
   */
  rtb_Accinsinsaturar = Controlador_U.In2 - Controlador_U.In1;

  /* Gain: '<S1>/Gain1' */
  rtb_Gain1 = rtb_Accinsinsaturar;

  /* Sum: '<S1>/Sum2' incorporates:
   *  DiscreteIntegrator: '<S1>/Discrete-Time Integrator'
   *  Gain: '<S1>/Gain'
   */
  rtb_Accinsinsaturar = 2.8 * rtb_Accinsinsaturar +
    Controlador_DW.DiscreteTimeIntegrator_DSTATE;

  /* Update for DiscreteIntegrator: '<S1>/Discrete-Time Integrator' */
  Controlador_DW.DiscreteTimeIntegrator_DSTATE += 0.01 * rtb_Gain1;
  if (Controlador_DW.DiscreteTimeIntegrator_DSTATE > 90.0) {
    Controlador_DW.DiscreteTimeIntegrator_DSTATE = 90.0;
  } else if (Controlador_DW.DiscreteTimeIntegrator_DSTATE < 0.0) {
    Controlador_DW.DiscreteTimeIntegrator_DSTATE = 0.0;
  }

  /* End of Update for DiscreteIntegrator: '<S1>/Discrete-Time Integrator' */

  /* Saturate: '<S1>/Saturaci�n de la acci�n' */
  if (rtb_Accinsinsaturar > 90.0) {
    /* Outport: '<Root>/Out1' */
    Controlador_Y.Out1 = 90.0;
  } else if (rtb_Accinsinsaturar < 0.0) {
    /* Outport: '<Root>/Out1' */
    Controlador_Y.Out1 = 0.0;
  } else {
    /* Outport: '<Root>/Out1' */
    Controlador_Y.Out1 = rtb_Accinsinsaturar;
  }

  /* End of Saturate: '<S1>/Saturaci�n de la acci�n' */
  /* End of Outputs for SubSystem: '<Root>/Controlador PI' */
}

/* Model initialize function */
void Controlador::initialize()
{
  /* (no initialization code required) */
}

/* Model terminate function */
void Controlador::terminate()
{
  /* (no terminate code required) */
}

/* Constructor */
Controlador::Controlador() :
  Controlador_U(),
  Controlador_Y(),
  Controlador_DW(),
  Controlador_M()
{
  /* Currently there is no constructor body generated.*/
}

/* Destructor */
/* Currently there is no destructor body generated.*/
Controlador::~Controlador() = default;

/* Real-Time Model get method */
RT_MODEL_Controlador_T * Controlador::getRTM()
{
  return (&Controlador_M);
}
